{% layout "../layout.liquid", questionInfoTypeMsg: "a **NON-NEGATIVE NUMERICAL VALUE**" %}
