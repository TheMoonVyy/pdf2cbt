{% layout "../layout.liquid", questionInfoTypeMsg: "a **POSITIVE NUMERICAL VALUE**" %}
