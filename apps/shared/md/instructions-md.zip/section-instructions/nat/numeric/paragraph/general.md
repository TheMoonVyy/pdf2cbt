{% layout "../../layout.liquid", decimalValueUpto: 2 %}

{%- block sectioninfo %}
- This section contains **{{ totalQuestions | toWords | upcase }} ({{ totalQuestions | zeroPad: 2 }})** paragraph-based questions.
{%- endblock %}