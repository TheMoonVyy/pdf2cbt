{% layout "../layout.liquid", questionInfoTypeMsg: "a **SINGLE DIGIT INTEGER** ranging from 0 to 9, both inclusive", typeMsg: "integer" %}
